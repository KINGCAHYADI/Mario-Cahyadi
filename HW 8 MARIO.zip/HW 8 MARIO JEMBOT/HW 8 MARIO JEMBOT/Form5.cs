﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW_8_MARIO_JEMBOT
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        Button[,] kursi = new Button[10, 10];
        int x = 10;
        int y = 10;

        List<Color> warnakursi = new List<Color>()
        {
            Color.Red,
            Color.Gray
        };

        private Color GetRandomColorOfList()
        {
            return warnakursi[rnd.Next(0, warnakursi.Count)];
        }

        private void Reservingseat_click(object sender, EventArgs e)
        {
            var tombolkursi = sender as Button;
            if (tombolkursi.BackColor == Color.Gray)
            {
                tombolkursi.BackColor = Color.Green;
                string[] split = tombolkursi.Tag.ToString().Split(',');
                Form1.kursiijo5.Add(split[0] + "," + split[1] + "," + split[2]);
            }
            if (tombolkursi.BackColor == Color.Red)
            {
                MessageBox.Show("cari kursi lain");
            }
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            if (Form1.count5 == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        kursi[i, j] = new Button();
                        kursi[i, j].Location = new Point(x, y);
                        kursi[i, j].Size = new Size(69, 68);
                        kursi[i, j].BackColor = GetRandomColorOfList();
                        kursi[i, j].Click += Reservingseat_click;
                        kursi[i, j].Tag = i + "," + j + ",NONE";
                        this.Controls.Add(kursi[i, j]);
                        x += 60;
                    }

                    y += 55;
                    x = 10;
                }
                int count = 0;
                foreach (Button b in kursi)
                {
                    if (b.BackColor == Color.Red)
                    {
                        Form1.kursimerah5.Add(count);
                    }
                    count++;
                }
            }

            if (Form1.count5 > 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        kursi[i, j] = new Button();
                        kursi[i, j].Location = new Point(x, y);
                        kursi[i, j].Size = new Size(69, 68);
                        kursi[i, j].Click += Reservingseat_click;
                        kursi[i, j].BackColor = Color.Gray;
                        kursi[i, j].Tag = i + "," + j + ",NONE";
                        this.Controls.Add(kursi[i, j]);
                        x += 60;
                    }

                    y += 55;
                    x = 10;
                }
                int count1 = 0;
                foreach (int n in Form1.kursimerah5)
                {
                    foreach (Button b in kursi)
                    {
                        if (n == count1)
                        {
                            b.BackColor = Color.Red;
                        }
                        count1++;
                    }
                    count1 = 0;
                }
                foreach (string u in Form1.kursiijo5)
                {
                    foreach (Button b in kursi)
                    {
                        if (u == b.Tag.ToString())
                        {
                            b.BackColor = Color.Green;
                        }
                    }
                }
            }
            Form1.count5++;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            foreach (Button b in kursi)
            {
                if (b.BackColor == Color.Green)
                {
                    b.BackColor = Color.Gray;
                    string[] split = b.Tag.ToString().Split(',');
                    Form1.kursiijo5.Remove(split[0] + "," + split[1] + "," + split[2]);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
