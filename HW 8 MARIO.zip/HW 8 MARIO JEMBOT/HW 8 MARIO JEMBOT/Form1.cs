﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW_8_MARIO_JEMBOT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] text = File.ReadAllLines(@"C:\Users\USER\Downloads\Movie.txt");

        public static int count1300 = 0;
        public static List<int> kursimerah1300 = new List<int>();
        public static List<string> kursiijo1300 = new List<string>();

        public static int count1500 = 0;
        public static List<int> kursimerah1500 = new List<int>();
        public static List<string> kursiijo1500 = new List<string>();

        public static int count1700 = 0;
        public static List<int> kursimerah1700 = new List<int>();
        public static List<string> kursiijo1700 = new List<string>();

        public static int count13002 = 0;
        public static List<int> kursimerah13002 = new List<int>();
        public static List<string> kursiijo13002 = new List<string>();

        public static int count15002 = 0;
        public static List<int> kursimerah15002 = new List<int>();
        public static List<string> kursiijo15002 = new List<string>();

        public static int count17002 = 0;
        public static List<int> kursimerah17002 = new List<int>();
        public static List<string> kursiijo17002 = new List<string>();

        public static int count13003 = 0;
        public static List<int> kursimerah13003 = new List<int>();
        public static List<string> kursiijo13003 = new List<string>();

        public static int count15003 = 0;
        public static List<int> kursimerah15003 = new List<int>();
        public static List<string> kursiijo15003 = new List<string>();

        public static int count17003 = 0;
        public static List<int> kursimerah17003 = new List<int>();
        public static List<string> kursiijo17003 = new List<string>();

        public static int count13004 = 0;
        public static List<int> kursimerah13004 = new List<int>();
        public static List<string> kursiijo13004 = new List<string>();

        public static int count15004 = 0;
        public static List<int> kursimerah15004 = new List<int>();
        public static List<string> kursiijo15004 = new List<string>();

        public static int count17004 = 0;
        public static List<int> kursimerah17004 = new List<int>();
        public static List<string> kursiijo17004 = new List<string>();

        public static int count2 = 0;
        public static List<int> kursimerah2 = new List<int>();
        public static List<string> kursiijo2 = new List<string>();

        public static int count3 = 0;
        public static List<int> kursimerah3 = new List<int>();
        public static List<string> kursiijo3 = new List<string>();

        public static int count4 = 0;
        public static List<int> kursimerah4 = new List<int>();
        public static List<string> kursiijo4 = new List<string>();

        public static int count5 = 0;
        public static List<int> kursimerah5 = new List<int>();
        public static List<string> kursiijo5 = new List<string>();

        public static int count6 = 0;
        public static List<int> kursimerah6 = new List<int>();
        public static List<string> kursiijo6 = new List<string>();

        public static int count7 = 0;
        public static List<int> kursimerah7 = new List<int>();
        public static List<string> kursiijo7 = new List<string>();


        public static int count8 = 0;
        public static List<int> kursimerah8 = new List<int>();
        public static List<string> kursiijo8 = new List<string>();


        public static int count9 = 0;
        public static List<int> kursimerah9 = new List<int>();
        public static List<string> kursiijo9 = new List<string>();

        public static int count10 = 0;
        public static List<int> kursimerah10 = new List<int>();
        public static List<string> kursiijo10 = new List<string>();

        public static int count11 = 0;
        public static List<int> kursimerah11 = new List<int>();
        public static List<string> kursiijo11 = new List<string>();


        public static int count12 = 0;
        public static List<int> kursimerah12 = new List<int>();
        public static List<string> kursiijo12 = new List<string>();


        public static int count13 = 0;
        public static List<int> kursimerah13 = new List<int>();
        public static List<string> kursiijo13 = new List<string>();
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] pisah = text[0].Split(',');
            label1.Text = pisah[0];
            label2.Text = pisah[1];
            label3.Text = pisah[2];
            label4.Text = pisah[3];
            label5.Text = pisah[4];
            label6.Text = pisah[5];
            label7.Text = pisah[6];
            label8.Text = pisah[7];
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            form1300 fr1300 = new form1300();
            fr1300.Dock = DockStyle.Fill;
            fr1300.TopLevel = false;
            fr1300.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr1300);
            fr1300.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            form1500 fr = new form1500();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            form1700 fr = new form1700();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            form13002 fr13002 = new form13002();
            fr13002.Dock = DockStyle.Fill;
            fr13002.TopLevel = false;
            fr13002.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr13002);
            fr13002.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            form15002 fr = new form15002();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            form17002 fr = new form17002();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            form13003 fr1300 = new form13003();
            fr1300.Dock = DockStyle.Fill;
            fr1300.TopLevel = false;
            fr1300.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr1300);
            fr1300.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            form15003 fr = new form15003();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            form17003 fr = new form17003();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            form13004 fr1300 = new form13004();
            fr1300.Dock = DockStyle.Fill;
            fr1300.TopLevel = false;
            fr1300.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr1300);
            fr1300.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            form15004 fr = new form15004();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            form17004 fr = new form17004();
            fr.Dock = DockStyle.Fill;
            fr.TopLevel = false;
            fr.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(fr);
            fr.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Dock = DockStyle.Fill;
            form2.TopLevel = false;
            form2.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form2);
            form2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Dock = DockStyle.Fill;
            form3.TopLevel = false;
            form3.FormBorderStyle = FormBorderStyle.None;   
            this.panel1.Controls.Add(form3);
            form3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Dock = DockStyle.Fill;
            form4.TopLevel = false;
            form4.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form4);
            form4.Show();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Dock = DockStyle.Fill;
                form5.TopLevel = false;
                form5.FormBorderStyle = FormBorderStyle.None;
                this.panel1.Controls.Add(form5);
                form5.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Dock = DockStyle.Fill;
                form6.TopLevel = false;
            form6.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form6);
            form6.Show();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Dock = DockStyle.Fill;
            form7.TopLevel = false;
            form7.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form7);
            form7.Show();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Dock = DockStyle.Fill;
            form8.TopLevel = false;
            form8.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form8);
            form8.Show();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.Dock = DockStyle.Fill;
            form9.TopLevel = false;
            form9.FormBorderStyle = FormBorderStyle.None;
                this.panel1.Controls.Add(form9);
            form9.Show();
                
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();
            form10.Dock = DockStyle.Fill;
            form10.TopLevel = false;
            form10.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form10);
            form10.Show();

        }

        private void button22_Click(object sender, EventArgs e)
        {
            Form11 form11 = new Form11();
            form11.Dock = DockStyle.Fill;
            form11.TopLevel = false;
            form11.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form11);
                form11.Show();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            Form12 form12 = new Form12();
            form12.Dock = DockStyle.Fill;
            form12.TopLevel = false;
            form12.FormBorderStyle = FormBorderStyle.None;
                this.panel1.Controls.Add(form12);
            form12.Show();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            Form13 form13 = new Form13();
            form13.Dock = DockStyle.Fill;
            form13.TopLevel = false;
            form13.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Add(form13);
            form13.Show();
        }
    }
}
